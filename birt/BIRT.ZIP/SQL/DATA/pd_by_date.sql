
INSERT INTO DWH.RPTEMPLATS (CODE, NAME, RTYPE, TEMPLATE, BROWSER, LAST_TS, LAST_USER, NOTE) VALUES ('PD_BY_DATE', '�������� �� ����', 2, 'INSERT INTO TMB03.DWH.RPTEMPLATS (ID, PARENT_ID, CODE, NAME, RTYPE, TEMPLATE, BROWSER, LAST_TS, LAST_USER, NOTE) VALUES (26, null, 'PD_BY_DATE', '�������� �� ����', 2, '<?xml version="1.0" encoding="UTF-8"?>
<report xmlns="http://www.eclipse.org/birt/2005/design" version="3.2.23" id="1">
    <property name="createdBy">Eclipse BIRT Designer Version 4.5.0.v201506092134 Build &lt;@BUILD@></property>
    <list-property name="propertyBindings">
        <structure>
            <property name="name">queryText</property>
            <property name="id">5</property>
        </structure>
        <structure>
            <property name="name">queryTimeOut</property>
            <property name="id">5</property>
        </structure>
        <structure>
            <property name="name">rowFetchSize</property>
            <property name="id">5</property>
        </structure>
    </list-property>
    <property name="units">in</property>
    <property name="iconFile">/templates/blank_report.gif</property>
    <property name="layoutPreference">fixed layout</property>
    <property name="bidiLayoutOrientation">ltr</property>
    <property name="imageDPI">96</property>
    <property name="locale">ru_RU</property>
    <parameters>
        <scalar-parameter name="pDate" id="271">
            <text-property name="helpText">���� ��������</text-property>
            <text-property name="promptText">������� ����</text-property>
            <property name="valueType">static</property>
            <property name="dataType">date</property>
            <property name="distinct">true</property>
            <simple-property-list name="defaultValue">
                <value type="constant">2016-03-01</value>
            </simple-property-list>
            <list-property name="selectionList"/>
            <property name="paramType">simple</property>
            <property name="controlType">text-box</property>
            <structure name="format">
                <property name="category">Custom</property>
                <property name="pattern">dd.MM.yyyy</property>
            </structure>
        </scalar-parameter>
    </parameters>
    <data-sources>
        <oda-data-source extensionID="org.eclipse.birt.report.data.oda.jdbc" name="Data Source" id="4">
            <list-property name="privateDriverProperties">
                <ex-property>
                    <name>metadataBidiFormatStr</name>
                    <value>ILYNN</value>
                </ex-property>
                <ex-property>
                    <name>disabledMetadataBidiFormatStr</name>
                </ex-property>
                <ex-property>
                    <name>contentBidiFormatStr</name>
                    <value>ILYNN</value>
                </ex-property>
                <ex-property>
                    <name>disabledContentBidiFormatStr</name>
                </ex-property>
            </list-property>
            <property name="odaDriverClass">com.ibm.as400.access.AS400JDBCDriver</property>
            <property name="odaURL">jdbc:as400://tmb03</property>
            <property name="odaUser">IMBUSER</property>
            <encrypted-property name="odaPassword" encryptionID="base64">eXRuZG9na2g3Ng==</encrypted-property>
        </oda-data-source>
    </data-sources>
    <data-sets>
        <oda-data-set extensionID="org.eclipse.birt.report.data.oda.jdbc.JdbcSelectDataSet" name="DataSet1" id="5">
            <property name="nullsOrdering">nulls lowest</property>
            <list-property name="columnHints">
                <structure>
                    <property name="columnName">ID</property>
                    <property name="analysis">measure</property>
                    <text-property name="displayName">ID</text-property>
                    <text-property name="heading">ID</text-property>
                </structure>
                <structure>
                    <property name="columnName">POD</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">POD</text-property>
                    <text-property name="heading">POD</text-property>
                </structure>
                <structure>
                    <property name="columnName">VALD</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">VALD</text-property>
                    <text-property name="heading">VALD</text-property>
                </structure>
                <structure>
                    <property name="columnName">ACID</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">ACID</text-property>
                    <text-property name="heading">ACID</text-property>
                </structure>
                <structure>
                    <property name="columnName">BSAACID</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">BSAACID</text-property>
                    <text-property name="heading">BSAACID</text-property>
                </structure>
                <structure>
                    <property name="columnName">CCY</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">CCY</text-property>
                    <text-property name="heading">CCY</text-property>
                </structure>
                <structure>
                    <property name="columnName">AMNT</property>
                    <property name="analysis">measure</property>
                    <text-property name="displayName">AMNT</text-property>
                    <text-property name="heading">AMNT</text-property>
                </structure>
                <structure>
                    <property name="columnName">AMNTBC</property>
                    <property name="analysis">measure</property>
                    <text-property name="displayName">AMNTBC</text-property>
                    <text-property name="heading">AMNTBC</text-property>
                </structure>
                <structure>
                    <property name="columnName">AMNTUC</property>
                    <property name="analysis">measure</property>
                    <text-property name="displayName">AMNTUC</text-property>
                    <text-property name="heading">AMNTUC</text-property>
                </structure>
                <structure>
                    <property name="columnName">PBR</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">PBR</text-property>
                    <text-property name="heading">PBR</text-property>
                </structure>
                <structure>
                    <property name="columnName">PDRF</property>
                    <property name="analysis">measure</property>
                    <text-property name="displayName">PDRF</text-property>
                    <text-property name="heading">PDRF</text-property>
                </structure>
                <structure>
                    <property name="columnName">CPDRF</property>
                    <property name="analysis">measure</property>
                    <text-property name="displayName">CPDRF</text-property>
                    <text-property name="heading">CPDRF</text-property>
                </structure>
                <structure>
                    <property name="columnName">INVISIBLE</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">INVISIBLE</text-property>
                    <text-property name="heading">INVISIBLE</text-property>
                </structure>
                <structure>
                    <property name="columnName">FINALETRS</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">FINALETRS</text-property>
                    <text-property name="heading">FINALETRS</text-property>
                </structure>
                <structure>
                    <property name="columnName">LASTD</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">LASTD</text-property>
                    <text-property name="heading">LASTD</text-property>
                </structure>
                <structure>
                    <property name="columnName">STATUS</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">STATUS</text-property>
                    <text-property name="heading">STATUS</text-property>
                </structure>
                <structure>
                    <property name="columnName">ASOC</property>
                    <property name="analysis">measure</property>
                    <text-property name="displayName">ASOC</text-property>
                    <text-property name="heading">ASOC</text-property>
                </structure>
                <structure>
                    <property name="columnName">PNAR</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">PNAR</text-property>
                    <text-property name="heading">PNAR</text-property>
                </structure>
                <structure>
                    <property name="columnName">CTYPE</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">CTYPE</text-property>
                    <text-property name="heading">CTYPE</text-property>
                </structure>
                <structure>
                    <property name="columnName">PCID</property>
                    <property name="analysis">measure</property>
                    <text-property name="displayName">PCID</text-property>
                    <text-property name="heading">PCID</text-property>
                </structure>
            </list-property>
            <list-property name="parameters">
                <structure>
                    <property name="name">pDate</property>
                    <property name="paramName">pDate</property>
                    <property name="nativeName"></property>
                    <property name="dataType">date</property>
                    <property name="nativeDataType">91</property>
                    <property name="position">1</property>
                    <expression name="defaultValue" type="javascript">30.12.2015</expression>
                    <property name="isOptional">true</property>
                    <property name="allowNull">true</property>
                    <property name="isInput">true</property>
                    <property name="isOutput">false</property>
                </structure>
            </list-property>
            <structure name="cachedMetaData">
                <list-property name="resultSet">
                    <structure>
                        <property name="position">1</property>
                        <property name="name">ID</property>
                        <property name="dataType">decimal</property>
                    </structure>
                    <structure>
                        <property name="position">2</property>
                        <property name="name">POD</property>
                        <property name="dataType">date</property>
                    </structure>
                    <structure>
                        <property name="position">3</property>
                        <property name="name">VALD</property>
                        <property name="dataType">date</property>
                    </structure>
                    <structure>
                        <property name="position">4</property>
                        <property name="name">ACID</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">5</property>
                        <property name="name">BSAACID</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">6</property>
                        <property name="name">CCY</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">7</property>
                        <property name="name">AMNT</property>
                        <property name="dataType">decimal</property>
                    </structure>
                    <structure>
                        <property name="position">8</property>
                        <property name="name">AMNTBC</property>
                        <property name="dataType">decimal</property>
                    </structure>
                    <structure>
                        <property name="position">9</property>
                        <property name="name">AMNTUC</property>
                        <property name="dataType">decimal</property>
                    </structure>
                    <structure>
                        <property name="position">10</property>
                        <property name="name">PBR</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">11</property>
                        <property name="name">PDRF</property>
                        <property name="dataType">decimal</property>
                    </structure>
                    <structure>
                        <property name="position">12</property>
                        <property name="name">CPDRF</property>
                        <property name="dataType">decimal</property>
                    </structure>
                    <structure>
                        <property name="position">13</property>
                        <property name="name">INVISIBLE</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">14</property>
                        <property name="name">FINALETRS</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">15</property>
                        <property name="name">LASTD</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">16</property>
                        <property name="name">STATUS</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">17</property>
                        <property name="name">ASOC</property>
                        <property name="dataType">decimal</property>
                    </structure>
                    <structure>
                        <property name="position">18</property>
                        <property name="name">PNAR</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">19</property>
                        <property name="name">CTYPE</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">20</property>
                        <property name="name">PCID</property>
                        <property name="dataType">decimal</property>
                    </structure>
                </list-property>
            </structure>
            <property name="dataSource">Data Source</property>
            <list-property name="resultSet">
                <structure>
                    <property name="position">1</property>
                    <property name="name">ID</property>
                    <property name="nativeName">ID</property>
                    <property name="dataType">decimal</property>
                    <property name="nativeDataType">-5</property>
                </structure>
                <structure>
                    <property name="position">2</property>
                    <property name="name">POD</property>
                    <property name="nativeName">POD</property>
                    <property name="dataType">date</property>
                    <property name="nativeDataType">91</property>
                </structure>
                <structure>
                    <property name="position">3</property>
                    <property name="name">VALD</property>
                    <property name="nativeName">VALD</property>
                    <property name="dataType">date</property>
                    <property name="nativeDataType">91</property>
                </structure>
                <structure>
                    <property name="position">4</property>
                    <property name="name">ACID</property>
                    <property name="nativeName">ACID</property>
                    <property name="dataType">string</property>
                    <property name="nativeDataType">12</property>
                </structure>
                <structure>
                    <property name="position">5</property>
                    <property name="name">BSAACID</property>
                    <property name="nativeName">BSAACID</property>
                    <property name="dataType">string</property>
                    <property name="nativeDataType">12</property>
                </structure>
                <structure>
                    <property name="position">6</property>
                    <property name="name">CCY</property>
                    <property name="nativeName">CCY</property>
                    <property name="dataType">string</property>
                    <property name="nativeDataType">12</property>
                </structure>
                <structure>
                    <property name="position">7</property>
                    <property name="name">AMNT</property>
                    <property name="nativeName">AMNT</property>
                    <property name="dataType">decimal</property>
                    <property name="nativeDataType">3</property>
                </structure>
                <structure>
                    <property name="position">8</property>
                    <property name="name">AMNTBC</property>
                    <property name="nativeName">AMNTBC</property>
                    <property name="dataType">decimal</property>
                    <property name="nativeDataType">3</property>
                </structure>
                <structure>
                    <property name="position">9</property>
                    <property name="name">AMNTUC</property>
                    <property name="nativeName">AMNTUC</property>
                    <property name="dataType">decimal</property>
                    <property name="nativeDataType">3</property>
                </structure>
                <structure>
                    <property name="position">10</property>
                    <property name="name">PBR</property>
                    <property name="nativeName">PBR</property>
                    <property name="dataType">string</property>
                    <property name="nativeDataType">12</property>
                </structure>
                <structure>
                    <property name="position">11</property>
                    <property name="name">PDRF</property>
                    <property name="nativeName">PDRF</property>
                    <property name="dataType">decimal</property>
                    <property name="nativeDataType">-5</property>
                </structure>
                <structure>
                    <property name="position">12</property>
                    <property name="name">CPDRF</property>
                    <property name="nativeName">CPDRF</property>
                    <property name="dataType">decimal</property>
                    <property name="nativeDataType">-5</property>
                </structure>
                <structure>
                    <property name="position">13</property>
                    <property name="name">INVISIBLE</property>
                    <property name="nativeName">INVISIBLE</property>
                    <property name="dataType">string</property>
                    <property name="nativeDataType">12</property>
                </structure>
                <structure>
                    <property name="position">14</property>
                    <property name="name">FINALETRS</property>
                    <property name="nativeName">FINALETRS</property>
                    <property name="dataType">string</property>
                    <property name="nativeDataType">12</property>
                </structure>
                <structure>
                    <property name="position">15</property>
                    <property name="name">LASTD</property>
                    <property name="nativeName">LASTD</property>
                    <property name="dataType">string</property>
                    <property name="nativeDataType">12</property>
                </structure>
                <structure>
                    <property name="position">16</property>
                    <property name="name">STATUS</property>
                    <property name="nativeName">STATUS</property>
                    <property name="dataType">string</property>
                    <property name="nativeDataType">12</property>
                </structure>
                <structure>
                    <property name="position">17</property>
                    <property name="name">ASOC</property>
                    <property name="nativeName">ASOC</property>
                    <property name="dataType">decimal</property>
                    <property name="nativeDataType">2</property>
                </structure>
                <structure>
                    <property name="position">18</property>
                    <property name="name">PNAR</property>
                    <property name="nativeName">PNAR</property>
                    <property name="dataType">string</property>
                    <property name="nativeDataType">12</property>
                </structure>
                <structure>
                    <property name="position">19</property>
                    <property name="name">CTYPE</property>
                    <property name="nativeName">CTYPE</property>
                    <property name="dataType">string</property>
                    <property name="nativeDataType">12</property>
                </structure>
                <structure>
                    <property name="position">20</property>
                    <property name="name">PCID</property>
                    <property name="nativeName">PCID</property>
                    <property name="dataType">decimal</property>
                    <property name="nativeDataType">-5</property>
                </structure>
            </list-property>
            <xml-property name="queryText"><![CDATA[select * from dwh.pd
where POD = ?
and PBR = ''@@IF-DE'']]></xml-property>
            <xml-property name="designerValues"><![CDATA[<?xml version="1.0" encoding="UTF-8"?>
<model:DesignValues xmlns:design="http://www.eclipse.org/datatools/connectivity/oda/design" xmlns:model="http://www.eclipse.org/birt/report/model/adapter/odaModel">
  <Version>2.0</Version>
  <design:ResultSets derivedMetaData="true">
    <design:resultSetDefinitions>
      <design:resultSetColumns>
        <design:resultColumnDefinitions>
          <design:attributes>
            <design:identifier>
              <design:name>book_id</design:name>
              <design:position>1</design:position>
            </design:identifier>
            <design:nativeDataTypeCode>-5</design:nativeDataTypeCode>
            <design:precision>19</design:precision>
            <design:scale>0</design:scale>
            <design:nullability>NotNullable</design:nullability>
            <design:uiHints>
              <design:displayName>book_id</design:displayName>
            </design:uiHints>
          </design:attributes>
          <design:usageHints>
            <design:label>book_id</design:label>
            <design:formattingHints>
              <design:displaySize>20</design:displaySize>
            </design:formattingHints>
          </design:usageHints>
        </design:resultColumnDefinitions>
        <design:resultColumnDefinitions>
          <design:attributes>
            <design:identifier>
              <design:name>book_name</design:name>
              <design:position>2</design:position>
            </design:identifier>
            <design:nativeDataTypeCode>12</design:nativeDataTypeCode>
            <design:precision>250</design:precision>
            <design:scale>0</design:scale>
            <design:nullability>Nullable</design:nullability>
            <design:uiHints>
              <design:displayName>book_name</design:displayName>
            </design:uiHints>
          </design:attributes>
          <design:usageHints>
            <design:label>book_name</design:label>
            <design:formattingHints>
              <design:displaySize>250</design:displaySize>
            </design:formattingHints>
          </design:usageHints>
        </design:resultColumnDefinitions>
        <design:resultColumnDefinitions>
          <design:attributes>
            <design:identifier>
              <design:name>author_id</design:name>
              <design:position>3</design:position>
            </design:identifier>
            <design:nativeDataTypeCode>-5</design:nativeDataTypeCode>
            <design:precision>19</design:precision>
            <design:scale>0</design:scale>
            <design:nullability>Nullable</design:nullability>
            <design:uiHints>
              <design:displayName>author_id</design:displayName>
            </design:uiHints>
          </design:attributes>
          <design:usageHints>
            <design:label>author_id</design:label>
            <design:formattingHints>
              <design:displaySize>20</design:displaySize>
            </design:formattingHints>
          </design:usageHints>
        </design:resultColumnDefinitions>
        <design:resultColumnDefinitions>
          <design:attributes>
            <design:identifier>
              <design:name>seria_id</design:name>
              <design:position>4</design:position>
            </design:identifier>
            <design:nativeDataTypeCode>-5</design:nativeDataTypeCode>
            <design:precision>19</design:precision>
            <design:scale>0</design:scale>
            <design:nullability>Nullable</design:nullability>
            <design:uiHints>
              <design:displayName>seria_id</design:displayName>
            </design:uiHints>
          </design:attributes>
          <design:usageHints>
            <design:label>seria_id</design:label>
            <design:formattingHints>
              <design:displaySize>20</design:displaySize>
            </design:formattingHints>
          </design:usageHints>
        </design:resultColumnDefinitions>
        <design:resultColumnDefinitions>
          <design:attributes>
            <design:identifier>
              <design:name>create_year</design:name>
              <design:position>5</design:position>
            </design:identifier>
            <design:nativeDataTypeCode>4</design:nativeDataTypeCode>
            <design:precision>10</design:precision>
            <design:scale>0</design:scale>
            <design:nullability>Nullable</design:nullability>
            <design:uiHints>
              <design:displayName>create_year</design:displayName>
            </design:uiHints>
          </design:attributes>
          <design:usageHints>
            <design:label>create_year</design:label>
            <design:formattingHints>
              <design:displaySize>11</design:displaySize>
            </design:formattingHints>
          </design:usageHints>
        </design:resultColumnDefinitions>
      </design:resultSetColumns>
      <design:criteria/>
    </design:resultSetDefinitions>
  </design:ResultSets>
</model:DesignValues>]]></xml-property>
        </oda-data-set>
    </data-sets>
    <styles>
        <style name="NewStyle" id="179"/>
        <style name="TOC-level-0" id="211"/>
    </styles>
    <page-setup>
        <simple-master-page name="Simple MasterPage" id="2">
            <property name="type">a4</property>
            <property name="orientation">auto</property>
            <property name="headerHeight">30mm</property>
            <property name="footerHeight">7mm</property>
            <page-header>
                <grid id="237">
                    <property name="textAlign">left</property>
                    <property name="overflow">auto</property>
                    <property name="height">0.9791666666666666in</property>
                    <property name="width">7.708333333333333in</property>
                    <column id="238">
                        <property name="width">7.708333333333333in</property>
                    </column>
                    <row id="251">
                        <property name="textAlign">center</property>
                        <property name="height">0.19791666666666666in</property>
                        <cell id="252">
                            <property name="textAlign">center</property>
                            <text id="253">
                                <property name="textAlign">left</property>
                                <property name="contentType">html</property>
                                <text-property name="content"><![CDATA[<value-of>new Date()</value-of>]]></text-property>
                            </text>
                        </cell>
                    </row>
                    <row id="239">
                        <property name="textAlign">center</property>
                        <property name="height">0.59375in</property>
                        <cell id="240">
                            <property name="textAlign">center</property>
                            <label id="243">
                                <property name="fontSize">14pt</property>
                                <property name="fontWeight">bold</property>
                                <property name="textAlign">center</property>
                                <text-property name="text">�������� �� ����</text-property>
                            </label>
                            <data id="333">
                                <structure name="dateTimeFormat">
                                    <property name="category">Custom</property>
                                    <property name="pattern">dd.MM.yyyy</property>
                                    <property name="locale">ru_RU</property>
                                </structure>
                                <structure name="stringFormat">
                                    <property name="category">Unformatted</property>
                                    <property name="locale">ru_RU</property>
                                </structure>
                                <list-property name="boundDataColumns">
                                    <structure>
                                        <property name="name">pDate</property>
                                        <expression name="expression" type="javascript">params["pDate"]</expression>
                                        <property name="dataType">date</property>
                                    </structure>
                                </list-property>
                                <property name="resultSetColumn">pDate</property>
                            </data>
                        </cell>
                    </row>
                </grid>
            </page-header>
            <page-footer>
                <grid id="254">
                    <property name="textAlign">left</property>
                    <property name="width">1.4166666666666667in</property>
                    <column id="267">
                        <property name="width">0.7083333333333334in</property>
                    </column>
                    <column id="255">
                        <property name="width">0.15625in</property>
                    </column>
                    <column id="256">
                        <property name="width">0.19791666666666666in</property>
                    </column>
                    <column id="257">
                        <property name="width">0.3541666666666667in</property>
                    </column>
                    <row id="258">
                        <cell id="266">
                            <property name="textAlign">justify</property>
                            <label id="268">
                                <property name="textAlign">left</property>
                                <text-property name="text">��������</text-property>
                            </label>
                        </cell>
                        <cell id="259">
                            <property name="textAlign">justify</property>
                            <auto-text id="260">
                                <property name="textAlign">left</property>
                                <property name="type">page-number</property>
                            </auto-text>
                        </cell>
                        <cell id="261">
                            <property name="textAlign">justify</property>
                            <text id="262">
                                <property name="textAlign">left</property>
                                <property name="contentType">plain</property>
                                <text-property name="content"><![CDATA[��]]></text-property>
                            </text>
                        </cell>
                        <cell id="263">
                            <property name="textAlign">justify</property>
                            <auto-text id="264">
                                <property name="textAlign">left</property>
                                <property name="type">total-page</property>
                            </auto-text>
                        </cell>
                    </row>
                </grid>
            </page-footer>
        </simple-master-page>
    </page-setup>
    <body>
        <table id="293">
            <property name="width">7.739583333333333in</property>
            <property name="dataSet">DataSet1</property>
            <list-property name="boundDataColumns">
                <structure>
                    <property name="name">POD</property>
                    <text-property name="displayName">POD</text-property>
                    <expression name="expression" type="javascript">dataSetRow["POD"]</expression>
                    <property name="dataType">date</property>
                </structure>
                <structure>
                    <property name="name">VALD</property>
                    <text-property name="displayName">VALD</text-property>
                    <expression name="expression" type="javascript">dataSetRow["VALD"]</expression>
                    <property name="dataType">date</property>
                </structure>
                <structure>
                    <property name="name">BSAACID</property>
                    <text-property name="displayName">BSAACID</text-property>
                    <expression name="expression" type="javascript">dataSetRow["BSAACID"]</expression>
                    <property name="dataType">string</property>
                </structure>
                <structure>
                    <property name="name">CCY</property>
                    <text-property name="displayName">CCY</text-property>
                    <expression name="expression" type="javascript">dataSetRow["CCY"]</expression>
                    <property name="dataType">string</property>
                </structure>
                <structure>
                    <property name="name">AMNT</property>
                    <text-property name="displayName">AMNT</text-property>
                    <expression name="expression" type="javascript">dataSetRow["AMNT"]</expression>
                    <property name="dataType">decimal</property>
                </structure>
                <structure>
                    <property name="name">PBR</property>
                    <text-property name="displayName">PBR</text-property>
                    <expression name="expression" type="javascript">dataSetRow["PBR"]</expression>
                    <property name="dataType">string</property>
                </structure>
            </list-property>
            <column id="327">
                <property name="width">0.9166666666666666in</property>
            </column>
            <column id="328">
                <property name="width">1.0625in</property>
            </column>
            <column id="329">
                <property name="width">2.1458333333333335in</property>
            </column>
            <column id="330">
                <property name="width">0.6666666666666666in</property>
            </column>
            <column id="331">
                <property name="width">1.84375in</property>
            </column>
            <column id="332">
                <property name="width">1.1041666666666667in</property>
            </column>
            <header>
                <row id="294">
                    <property name="borderBottomStyle">solid</property>
                    <property name="borderBottomWidth">medium</property>
                    <property name="borderLeftStyle">solid</property>
                    <property name="borderLeftWidth">medium</property>
                    <property name="borderRightStyle">solid</property>
                    <property name="borderRightWidth">medium</property>
                    <property name="borderTopStyle">solid</property>
                    <property name="borderTopWidth">medium</property>
                    <cell id="295">
                        <property name="borderBottomStyle">solid</property>
                        <property name="borderBottomWidth">medium</property>
                        <property name="borderLeftStyle">solid</property>
                        <property name="borderLeftWidth">medium</property>
                        <property name="borderRightStyle">solid</property>
                        <property name="borderRightWidth">medium</property>
                        <property name="borderTopStyle">solid</property>
                        <property name="borderTopWidth">medium</property>
                        <label id="296">
                            <text-property name="text">POD</text-property>
                        </label>
                    </cell>
                    <cell id="297">
                        <property name="borderBottomStyle">solid</property>
                        <property name="borderBottomWidth">medium</property>
                        <property name="borderLeftStyle">solid</property>
                        <property name="borderLeftWidth">medium</property>
                        <property name="borderRightStyle">solid</property>
                        <property name="borderRightWidth">medium</property>
                        <property name="borderTopStyle">solid</property>
                        <property name="borderTopWidth">medium</property>
                        <label id="298">
                            <text-property name="text">VALD</text-property>
                        </label>
                    </cell>
                    <cell id="299">
                        <property name="borderBottomStyle">solid</property>
                        <property name="borderBottomWidth">medium</property>
                        <property name="borderLeftStyle">solid</property>
                        <property name="borderLeftWidth">medium</property>
                        <property name="borderRightStyle">solid</property>
                        <property name="borderRightWidth">medium</property>
                        <property name="borderTopStyle">solid</property>
                        <property name="borderTopWidth">medium</property>
                        <label id="300">
                            <text-property name="text">BSAACID</text-property>
                        </label>
                    </cell>
                    <cell id="301">
                        <property name="borderBottomStyle">solid</property>
                        <property name="borderBottomWidth">medium</property>
                        <property name="borderLeftStyle">solid</property>
                        <property name="borderLeftWidth">medium</property>
                        <property name="borderRightStyle">solid</property>
                        <property name="borderRightWidth">medium</property>
                        <property name="borderTopStyle">solid</property>
                        <property name="borderTopWidth">medium</property>
                        <label id="302">
                            <text-property name="text">CCY</text-property>
                        </label>
                    </cell>
                    <cell id="303">
                        <property name="borderBottomStyle">solid</property>
                        <property name="borderBottomWidth">medium</property>
                        <property name="borderLeftStyle">solid</property>
                        <property name="borderLeftWidth">medium</property>
                        <property name="borderRightStyle">solid</property>
                        <property name="borderRightWidth">medium</property>
                        <property name="borderTopStyle">solid</property>
                        <property name="borderTopWidth">medium</property>
                        <label id="304">
                            <text-property name="text">AMNT</text-property>
                        </label>
                    </cell>
                    <cell id="305">
                        <property name="borderBottomStyle">solid</property>
                        <property name="borderBottomWidth">medium</property>
                        <property name="borderLeftStyle">solid</property>
                        <property name="borderLeftWidth">medium</property>
                        <property name="borderRightStyle">solid</property>
                        <property name="borderRightWidth">medium</property>
                        <property name="borderTopStyle">solid</property>
                        <property name="borderTopWidth">medium</property>
                        <label id="306">
                            <text-property name="text">PBR</text-property>
                        </label>
                    </cell>
                </row>
            </header>
            <detail>
                <row id="307">
                    <property name="borderBottomStyle">solid</property>
                    <property name="borderBottomWidth">1px</property>
                    <property name="borderLeftStyle">solid</property>
                    <property name="borderLeftWidth">1px</property>
                    <property name="borderRightStyle">solid</property>
                    <property name="borderRightWidth">1px</property>
                    <property name="borderTopStyle">solid</property>
                    <property name="borderTopWidth">1px</property>
                    <cell id="308">
                        <property name="borderBottomStyle">solid</property>
                        <property name="borderBottomWidth">1px</property>
                        <property name="borderLeftStyle">solid</property>
                        <property name="borderLeftWidth">1px</property>
                        <property name="borderRightStyle">solid</property>
                        <property name="borderRightWidth">1px</property>
                        <property name="borderTopStyle">solid</property>
                        <property name="borderTopWidth">1px</property>
                        <data id="309">
                            <structure name="dateTimeFormat">
                                <property name="category">Custom</property>
                                <property name="pattern">dd.MM.yyyy</property>
                                <property name="locale">ru_RU</property>
                            </structure>
                            <structure name="numberFormat">
                                <property name="category">Currency</property>
                                <property name="pattern">#,##0.00{RoundingMode=HALF_UP}</property>
                                <property name="locale">rn</property>
                            </structure>
                            <property name="textAlign">center</property>
                            <property name="resultSetColumn">POD</property>
                        </data>
                    </cell>
                    <cell id="310">
                        <property name="borderBottomStyle">solid</property>
                        <property name="borderBottomWidth">1px</property>
                        <property name="borderLeftStyle">solid</property>
                        <property name="borderLeftWidth">1px</property>
                        <property name="borderRightStyle">solid</property>
                        <property name="borderRightWidth">1px</property>
                        <property name="borderTopStyle">solid</property>
                        <property name="borderTopWidth">1px</property>
                        <data id="311">
                            <property name="backgroundAttachment">scroll</property>
                            <property name="backgroundPositionX">0%</property>
                            <property name="backgroundPositionY">0%</property>
                            <property name="backgroundRepeat">repeat</property>
                            <property name="fontFamily">serif</property>
                            <property name="fontSize">10pt</property>
                            <property name="fontWeight">normal</property>
                            <property name="fontStyle">normal</property>
                            <property name="fontVariant">normal</property>
                            <property name="color">black</property>
                            <property name="textLineThrough">none</property>
                            <property name="textOverline">none</property>
                            <property name="textUnderline">none</property>
                            <property name="borderBottomColor">black</property>
                            <property name="borderBottomStyle">none</property>
                            <property name="borderBottomWidth">medium</property>
                            <property name="borderLeftColor">black</property>
                            <property name="borderLeftStyle">none</property>
                            <property name="borderLeftWidth">medium</property>
                            <property name="borderRightColor">black</property>
                            <property name="borderRightStyle">none</property>
                            <property name="borderRightWidth">medium</property>
                            <property name="borderTopColor">black</property>
                            <property name="borderTopStyle">none</property>
                            <property name="borderTopWidth">medium</property>
                            <property name="marginTop">0pt</property>
                            <property name="marginLeft">0pt</property>
                            <property name="marginBottom">0pt</property>
                            <property name="marginRight">0pt</property>
                            <property name="paddingTop">1pt</property>
                            <property name="paddingLeft">1pt</property>
                            <property name="paddingBottom">1pt</property>
                            <property name="paddingRight">1pt</property>
                            <structure name="dateTimeFormat">
                                <property name="category">Custom</property>
                                <property name="pattern">dd.MM.yyyy</property>
                                <property name="locale">ru_RU</property>
                            </structure>
                            <structure name="numberFormat">
                                <property name="category">Currency</property>
                                <property name="pattern">#,##0.00{RoundingMode=HALF_UP}</property>
                                <property name="locale">rn</property>
                            </structure>
                            <property name="textAlign">center</property>
                            <property name="letterSpacing">normal</property>
                            <property name="lineHeight">normal</property>
                            <property name="orphans">2</property>
                            <property name="textTransform">none</property>
                            <property name="whiteSpace">normal</property>
                            <property name="widows">2</property>
                            <property name="wordSpacing">normal</property>
                            <property name="display">block</property>
                            <property name="pageBreakAfter">auto</property>
                            <property name="pageBreakBefore">auto</property>
                            <property name="pageBreakInside">auto</property>
                            <property name="showIfBlank">false</property>
                            <property name="canShrink">false</property>
                            <property name="overflow">hidden</property>
                            <property name="resultSetColumn">VALD</property>
                        </data>
                    </cell>
                    <cell id="312">
                        <property name="borderBottomStyle">solid</property>
                        <property name="borderBottomWidth">1px</property>
                        <property name="borderLeftStyle">solid</property>
                        <property name="borderLeftWidth">1px</property>
                        <property name="borderRightStyle">solid</property>
                        <property name="borderRightWidth">1px</property>
                        <property name="borderTopStyle">solid</property>
                        <property name="borderTopWidth">1px</property>
                        <data id="313">
                            <property name="borderBottomStyle">none</property>
                            <property name="borderLeftStyle">none</property>
                            <property name="borderRightStyle">none</property>
                            <property name="borderTopStyle">none</property>
                            <property name="resultSetColumn">BSAACID</property>
                        </data>
                    </cell>
                    <cell id="314">
                        <property name="borderBottomStyle">solid</property>
                        <property name="borderBottomWidth">1px</property>
                        <property name="borderLeftStyle">solid</property>
                        <property name="borderLeftWidth">1px</property>
                        <property name="borderRightStyle">solid</property>
                        <property name="borderRightWidth">1px</property>
                        <property name="borderTopStyle">solid</property>
                        <property name="borderTopWidth">1px</property>
                        <data id="315">
                            <property name="textAlign">center</property>
                            <property name="resultSetColumn">CCY</property>
                        </data>
                    </cell>
                    <cell id="316">
                        <property name="borderBottomStyle">solid</property>
                        <property name="borderBottomWidth">1px</property>
                        <property name="borderLeftStyle">solid</property>
                        <property name="borderLeftWidth">1px</property>
                        <property name="borderRightStyle">solid</property>
                        <property name="borderRightWidth">1px</property>
                        <property name="borderTopStyle">solid</property>
                        <property name="borderTopWidth">1px</property>
                        <data id="317">
                            <property name="borderBottomStyle">none</property>
                            <property name="borderLeftStyle">none</property>
                            <property name="borderRightStyle">none</property>
                            <property name="borderTopStyle">none</property>
                            <property name="textAlign">right</property>
                            <property name="resultSetColumn">AMNT</property>
                        </data>
                    </cell>
                    <cell id="318">
                        <property name="borderBottomStyle">solid</property>
                        <property name="borderBottomWidth">1px</property>
                        <property name="borderLeftStyle">solid</property>
                        <property name="borderLeftWidth">1px</property>
                        <property name="borderRightStyle">solid</property>
                        <property name="borderRightWidth">1px</property>
                        <property name="borderTopStyle">solid</property>
                        <property name="borderTopWidth">1px</property>
                        <data id="319">
                            <property name="borderBottomStyle">none</property>
                            <property name="borderLeftStyle">none</property>
                            <property name="borderRightStyle">none</property>
                            <property name="borderTopStyle">none</property>
                            <property name="resultSetColumn">PBR</property>
                        </data>
                    </cell>
                </row>
            </detail>
            <footer>
                <row id="320">
                    <cell id="321"/>
                    <cell id="322"/>
                    <cell id="323"/>
                    <cell id="324"/>
                    <cell id="325"/>
                    <cell id="326"/>
                </row>
            </footer>
        </table>
    </body>
</report>
', '', '2016-03-28 17:01:03.468485', 'IMBUSER', null);
', '', '2016-03-28 16:35:29.494495', 'IMBUSER', null);


insert into
DWH.RP_SQLS ( 
	RPTEMPLATS_ID, 
	PARENT_ID, 
	ORDER_NUM, 
	SQL_TEXT
    )
    VALUES
    (
	26, 
	null, 
	1, 
	'select * from dwh.pd where POD = ? and PBR = ''@@IF-DE'''
    );


insert into
DWH.RP_PARAMS ( 
	RP_SQLS_ID, 
    CODE,
    NAME,
    DATA_TYPE,
    DATA_DIM,
    VALUE,
    REQUIRE_SIGN,
    SAVE_SIGN,
    HIDDEN_SIGN,
    SHOW_ORDER,
    PARAMS
)
VALUES
(
    3, 
    'pDate',
    '���� ������',
    3,
    0,
    '2016-03-01',
    1,
    1,
    0,
    1,
    null
);    

