
INSERT INTO DWH.RPTEMPLATS (CODE, NAME, RTYPE, TEMPLATE, BROWSER, LAST_TS, LAST_USER, NOTE) VALUES ('BALANCE_CONTROL', '�������� ��������', 2, '<?xml version="1.0" encoding="UTF-8"?>
<report xmlns="http://www.eclipse.org/birt/2005/design" version="3.2.23" id="1">
    <property name="createdBy">Eclipse BIRT Designer Version 4.5.0.v201506092134 Build &lt;@BUILD@></property>
    <simple-property-list name="includeResource">
        <value>Messages_ru</value>
    </simple-property-list>
    <list-property name="propertyBindings">
        <structure>
            <property name="name">queryText</property>
            <property name="id">5</property>
        </structure>
        <structure>
            <property name="name">queryTimeOut</property>
            <property name="id">5</property>
        </structure>
        <structure>
            <property name="name">rowFetchSize</property>
            <property name="id">5</property>
        </structure>
    </list-property>
    <property name="units">in</property>
    <property name="iconFile">/templates/blank_report.gif</property>
    <property name="layoutPreference">fixed layout</property>
    <property name="bidiLayoutOrientation">ltr</property>
    <property name="imageDPI">96</property>
    <property name="locale">ru_RU</property>
    <parameters>
        <scalar-parameter name="pDate" id="180">
            <text-property name="promptText">���� ��</text-property>
            <property name="valueType">static</property>
            <property name="dataType">date</property>
            <property name="distinct">true</property>
            <simple-property-list name="defaultValue">
                <value type="constant">2016-03-01</value>
            </simple-property-list>
            <list-property name="selectionList"/>
            <property name="paramType">simple</property>
            <property name="controlType">text-box</property>
            <structure name="format">
                <property name="category">Custom</property>
                <property name="pattern">dd.MM.YYYY</property>
            </structure>
        </scalar-parameter>
        <scalar-parameter name="pBranch" id="181">
            <text-property name="helpText">������� ��� �������</text-property>
            <text-property name="promptText">������:</text-property>
            <property name="valueType">static</property>
            <property name="isRequired">false</property>
            <property name="dataType">string</property>
            <property name="distinct">true</property>
            <simple-property-list name="defaultValue">
                <value type="constant">0002</value>
            </simple-property-list>
            <list-property name="selectionList"/>
            <property name="paramType">simple</property>
            <property name="concealValue">false</property>
            <property name="controlType">text-box</property>
            <structure name="format">
                <property name="category">Unformatted</property>
            </structure>
        </scalar-parameter>
    </parameters>
    <data-sources>
        <oda-data-source extensionID="org.eclipse.birt.report.data.oda.jdbc" name="Data Source" id="4">
            <list-property name="privateDriverProperties">
                <ex-property>
                    <name>metadataBidiFormatStr</name>
                    <value>ILYNN</value>
                </ex-property>
                <ex-property>
                    <name>disabledMetadataBidiFormatStr</name>
                </ex-property>
                <ex-property>
                    <name>contentBidiFormatStr</name>
                    <value>ILYNN</value>
                </ex-property>
                <ex-property>
                    <name>disabledContentBidiFormatStr</name>
                </ex-property>
            </list-property>
            <property name="odaDriverClass">com.ibm.as400.access.AS400JDBCDriver</property>
            <property name="odaURL">jdbc:as400://tmb03</property>
            <property name="odaUser">IMBUSER</property>
            <encrypted-property name="odaPassword" encryptionID="base64">eXRuZG9na2g3Ng==</encrypted-property>
        </oda-data-source>
    </data-sources>
    <data-sets>
        <oda-data-set extensionID="org.eclipse.birt.report.data.oda.jdbc.JdbcSelectDataSet" name="MainDataSet" id="5">
            <property name="nullsOrdering">nulls lowest</property>
            <list-property name="columnHints">
                <structure>
                    <property name="columnName">TODAT</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">TODAT</text-property>
                    <property name="onColumnLayout">false</property>
                    <text-property name="heading">TODAT</text-property>
                </structure>
                <structure>
                    <property name="columnName">TYPE</property>
                    <property name="analysis">dimension</property>
                    <text-property name="displayName">TYPE</text-property>
                    <property name="onColumnLayout">false</property>
                    <text-property name="heading">TYPE</text-property>
                </structure>
                <structure>
                    <property name="columnName">CBA</property>
                    <property name="analysis">measure</property>
                    <text-property name="displayName">CBA</text-property>
                    <property name="onColumnLayout">false</property>
                    <text-property name="heading">CBA</text-property>
                </structure>
                <structure>
                    <property name="columnName">CBP</property>
                    <property name="analysis">measure</property>
                    <text-property name="displayName">CBP</text-property>
                    <property name="onColumnLayout">false</property>
                    <text-property name="heading">CBP</text-property>
                </structure>
            </list-property>
            <list-property name="parameters">
                <structure>
                    <property name="name">pDate</property>
                    <property name="paramName">pDate</property>
                    <property name="nativeName"></property>
                    <property name="dataType">date</property>
                    <property name="nativeDataType">91</property>
                    <property name="position">1</property>
                    <property name="isOptional">true</property>
                    <property name="allowNull">true</property>
                    <property name="isInput">true</property>
                    <property name="isOutput">false</property>
                </structure>
                <structure>
                    <property name="name">pBranch</property>
                    <property name="paramName">pBranch</property>
                    <property name="nativeName"></property>
                    <property name="dataType">string</property>
                    <property name="nativeDataType">12</property>
                    <property name="position">2</property>
                    <property name="isOptional">true</property>
                    <property name="allowNull">true</property>
                    <property name="isInput">true</property>
                    <property name="isOutput">false</property>
                </structure>
            </list-property>
            <structure name="cachedMetaData">
                <list-property name="resultSet">
                    <structure>
                        <property name="position">1</property>
                        <property name="name">TODAT</property>
                        <property name="dataType">date</property>
                    </structure>
                    <structure>
                        <property name="position">2</property>
                        <property name="name">TYPE</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">3</property>
                        <property name="name">CBA</property>
                        <property name="dataType">decimal</property>
                    </structure>
                    <structure>
                        <property name="position">4</property>
                        <property name="name">CBP</property>
                        <property name="dataType">decimal</property>
                    </structure>
                </list-property>
            </structure>
            <property name="dataSource">Data Source</property>
            <list-property name="resultSet">
                <structure>
                    <property name="position">1</property>
                    <property name="name">TODAT</property>
                    <property name="nativeName">TODAT</property>
                    <property name="dataType">date</property>
                    <property name="nativeDataType">91</property>
                </structure>
                <structure>
                    <property name="position">2</property>
                    <property name="name">TYPE</property>
                    <property name="nativeName">TYPE</property>
                    <property name="dataType">string</property>
                    <property name="nativeDataType">12</property>
                </structure>
                <structure>
                    <property name="position">3</property>
                    <property name="name">CBA</property>
                    <property name="nativeName">CBA</property>
                    <property name="dataType">decimal</property>
                    <property name="nativeDataType">3</property>
                </structure>
                <structure>
                    <property name="position">4</property>
                    <property name="name">CBP</property>
                    <property name="nativeName">CBP</property>
                    <property name="dataType">decimal</property>
                    <property name="nativeDataType">3</property>
                </structure>
            </list-property>
            <xml-property name="queryText"><![CDATA[call DWH.DWHBALCHK(?,?)]]></xml-property>
            <xml-property name="designerValues"><![CDATA[<?xml version="1.0" encoding="UTF-8"?>
<model:DesignValues xmlns:design="http://www.eclipse.org/datatools/connectivity/oda/design" xmlns:model="http://www.eclipse.org/birt/report/model/adapter/odaModel">
  <Version>2.0</Version>
  <design:ResultSets derivedMetaData="true">
    <design:resultSetDefinitions>
      <design:resultSetColumns>
        <design:resultColumnDefinitions>
          <design:attributes>
            <design:identifier>
              <design:name>book_id</design:name>
              <design:position>1</design:position>
            </design:identifier>
            <design:nativeDataTypeCode>-5</design:nativeDataTypeCode>
            <design:precision>19</design:precision>
            <design:scale>0</design:scale>
            <design:nullability>NotNullable</design:nullability>
            <design:uiHints>
              <design:displayName>book_id</design:displayName>
            </design:uiHints>
          </design:attributes>
          <design:usageHints>
            <design:label>book_id</design:label>
            <design:formattingHints>
              <design:displaySize>20</design:displaySize>
            </design:formattingHints>
          </design:usageHints>
        </design:resultColumnDefinitions>
        <design:resultColumnDefinitions>
          <design:attributes>
            <design:identifier>
              <design:name>book_name</design:name>
              <design:position>2</design:position>
            </design:identifier>
            <design:nativeDataTypeCode>12</design:nativeDataTypeCode>
            <design:precision>250</design:precision>
            <design:scale>0</design:scale>
            <design:nullability>Nullable</design:nullability>
            <design:uiHints>
              <design:displayName>book_name</design:displayName>
            </design:uiHints>
          </design:attributes>
          <design:usageHints>
            <design:label>book_name</design:label>
            <design:formattingHints>
              <design:displaySize>250</design:displaySize>
            </design:formattingHints>
          </design:usageHints>
        </design:resultColumnDefinitions>
        <design:resultColumnDefinitions>
          <design:attributes>
            <design:identifier>
              <design:name>author_id</design:name>
              <design:position>3</design:position>
            </design:identifier>
            <design:nativeDataTypeCode>-5</design:nativeDataTypeCode>
            <design:precision>19</design:precision>
            <design:scale>0</design:scale>
            <design:nullability>Nullable</design:nullability>
            <design:uiHints>
              <design:displayName>author_id</design:displayName>
            </design:uiHints>
          </design:attributes>
          <design:usageHints>
            <design:label>author_id</design:label>
            <design:formattingHints>
              <design:displaySize>20</design:displaySize>
            </design:formattingHints>
          </design:usageHints>
        </design:resultColumnDefinitions>
        <design:resultColumnDefinitions>
          <design:attributes>
            <design:identifier>
              <design:name>seria_id</design:name>
              <design:position>4</design:position>
            </design:identifier>
            <design:nativeDataTypeCode>-5</design:nativeDataTypeCode>
            <design:precision>19</design:precision>
            <design:scale>0</design:scale>
            <design:nullability>Nullable</design:nullability>
            <design:uiHints>
              <design:displayName>seria_id</design:displayName>
            </design:uiHints>
          </design:attributes>
          <design:usageHints>
            <design:label>seria_id</design:label>
            <design:formattingHints>
              <design:displaySize>20</design:displaySize>
            </design:formattingHints>
          </design:usageHints>
        </design:resultColumnDefinitions>
        <design:resultColumnDefinitions>
          <design:attributes>
            <design:identifier>
              <design:name>create_year</design:name>
              <design:position>5</design:position>
            </design:identifier>
            <design:nativeDataTypeCode>4</design:nativeDataTypeCode>
            <design:precision>10</design:precision>
            <design:scale>0</design:scale>
            <design:nullability>Nullable</design:nullability>
            <design:uiHints>
              <design:displayName>create_year</design:displayName>
            </design:uiHints>
          </design:attributes>
          <design:usageHints>
            <design:label>create_year</design:label>
            <design:formattingHints>
              <design:displaySize>11</design:displaySize>
            </design:formattingHints>
          </design:usageHints>
        </design:resultColumnDefinitions>
      </design:resultSetColumns>
      <design:criteria/>
    </design:resultSetDefinitions>
  </design:ResultSets>
</model:DesignValues>]]></xml-property>
        </oda-data-set>
        <oda-data-set extensionID="org.eclipse.birt.report.data.oda.jdbc.SPSelectDataSet" name="SubRepDataSet" id="269">
            <list-property name="columnHints"/>
            <list-property name="parameters">
                <structure>
                    <property name="name">PBRCA</property>
                    <property name="paramName">pBranch</property>
                    <property name="nativeName">PBRCA</property>
                    <property name="dataType">string</property>
                    <property name="nativeDataType">12</property>
                    <property name="position">1</property>
                    <property name="isOptional">true</property>
                    <property name="allowNull">true</property>
                    <property name="isInput">true</property>
                    <property name="isOutput">false</property>
                </structure>
            </list-property>
            <structure name="cachedMetaData">
                <list-property name="resultSet">
                    <structure>
                        <property name="position">1</property>
                        <property name="name">BBCUST</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">2</property>
                        <property name="name">BR_RAS_NM</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">3</property>
                        <property name="name">PST_ADR</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">4</property>
                        <property name="name">OKATO_CD</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">5</property>
                        <property name="name">OKPO_CD</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">6</property>
                        <property name="name">REG_NO</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">7</property>
                        <property name="name">BIC_CD</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">8</property>
                        <property name="name">CCBBR</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">9</property>
                        <property name="name">RPT_H_NAME</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">10</property>
                        <property name="name">RPT_CODE</property>
                        <property name="dataType">string</property>
                    </structure>
                    <structure>
                        <property name="position">11</property>
                        <property name="name">RPT_FREC</property>
                        <property name="dataType">string</property>
                    </structure>
                </list-property>
            </structure>
            <property name="dataSource">Data Source</property>
            <list-property name="resultSet">
                <structure>
                    <property name="position">1</property>
                    <property name="name">BBCUST</property>
                    <property name="nativeName">BBCUST</property>
                    <property name="dataType">string</property>
                </structure>
                <structure>
                    <property name="position">2</property>
                    <property name="name">BR_RAS_NM</property>
                    <property name="nativeName">BR_RAS_NM</property>
                    <property name="dataType">string</property>
                </structure>
                <structure>
                    <property name="position">3</property>
                    <property name="name">PST_ADR</property>
                    <property name="nativeName">PST_ADR</property>
                    <property name="dataType">string</property>
                </structure>
                <structure>
                    <property name="position">4</property>
                    <property name="name">OKATO_CD</property>
                    <property name="nativeName">OKATO_CD</property>
                    <property name="dataType">string</property>
                </structure>
                <structure>
                    <property name="position">5</property>
                    <property name="name">OKPO_CD</property>
                    <property name="nativeName">OKPO_CD</property>
                    <property name="dataType">string</property>
                </structure>
                <structure>
                    <property name="position">6</property>
                    <property name="name">REG_NO</property>
                    <property name="nativeName">REG_NO</property>
                    <property name="dataType">string</property>
                </structure>
                <structure>
                    <property name="position">7</property>
                    <property name="name">BIC_CD</property>
                    <property name="nativeName">BIC_CD</property>
                    <property name="dataType">string</property>
                </structure>
                <structure>
                    <property name="position">8</property>
                    <property name="name">CCBBR</property>
                    <property name="nativeName">CCBBR</property>
                    <property name="dataType">string</property>
                </structure>
                <structure>
                    <property name="position">9</property>
                    <property name="name">RPT_H_NAME</property>
                    <property name="nativeName">RPT_H_NAME</property>
                    <property name="dataType">string</property>
                </structure>
                <structure>
                    <property name="position">10</property>
                    <property name="name">RPT_CODE</property>
                    <property name="nativeName">RPT_CODE</property>
                    <property name="dataType">string</property>
                </structure>
                <structure>
                    <property name="position">11</property>
                    <property name="name">RPT_FREC</property>
                    <property name="nativeName">RPT_FREC</property>
                    <property name="dataType">string</property>
                </structure>
            </list-property>
            <xml-property name="queryText"><![CDATA[call DWH.DWH_BRDATA(?,'''')]]></xml-property>
            <xml-property name="designerValues"><![CDATA[<?xml version="1.0" encoding="UTF-8"?>
<model:DesignValues xmlns:design="http://www.eclipse.org/datatools/connectivity/oda/design" xmlns:model="http://www.eclipse.org/birt/report/model/adapter/odaModel">
  <Version>2.0</Version>
  <DataSetParameters>
    <parameter>
      <design:ParameterDefinition>
        <design:inOutMode>In</design:inOutMode>
        <design:attributes>
          <design:identifier>
            <design:name>PBRCA</design:name>
            <design:position>1</design:position>
          </design:identifier>
          <design:nativeDataTypeCode>12</design:nativeDataTypeCode>
          <design:precision>0</design:precision>
          <design:scale>0</design:scale>
          <design:nullability>Nullable</design:nullability>
        </design:attributes>
        <design:inputAttributes>
          <design:elementAttributes>
            <design:optional>true</design:optional>
          </design:elementAttributes>
        </design:inputAttributes>
      </design:ParameterDefinition>
    </parameter>
  </DataSetParameters>
</model:DesignValues>]]></xml-property>
        </oda-data-set>
    </data-sets>
    <styles>
        <style name="NewStyle" id="179"/>
        <style name="TOC-level-0" id="211"/>
    </styles>
    <page-setup>
        <simple-master-page name="Simple MasterPage" id="2">
            <property name="type">a4</property>
            <property name="orientation">auto</property>
            <property name="headerHeight">30mm</property>
            <property name="footerHeight">7mm</property>
            <page-header>
                <grid id="237">
                    <property name="textAlign">left</property>
                    <property name="overflow">auto</property>
                    <property name="height">1.0833333333333333in</property>
                    <property name="width">7.708333333333333in</property>
                    <column id="238">
                        <property name="width">7.708333333333333in</property>
                    </column>
                    <row id="251">
                        <property name="textAlign">center</property>
                        <property name="height">0.19791666666666666in</property>
                        <cell id="252">
                            <property name="textAlign">center</property>
                            <text id="253">
                                <property name="textAlign">left</property>
                                <property name="contentType">html</property>
                                <text-property name="content"><![CDATA[<value-of>new Date()</value-of>]]></text-property>
                            </text>
                        </cell>
                    </row>
                    <row id="239">
                        <property name="textAlign">center</property>
                        <property name="height">0.59375in</property>
                        <cell id="240">
                            <property name="textAlign">center</property>
                            <label id="243">
                                <property name="fontSize">14pt</property>
                                <property name="fontWeight">bold</property>
                                <property name="textAlign">center</property>
                                <text-property name="text">�������� ��������</text-property>
                            </label>
                            <data id="270">
                                <list-property name="boundDataColumns">
                                    <structure>
                                        <property name="name">pDate</property>
                                        <text-property name="displayName">�� �������� ������ �  ��</text-property>
                                        <expression name="expression" type="javascript">"�� �������� ������ � " + vars["startDate"] + " �� " + vars["endDate"]</expression>
                                        <property name="dataType">string</property>
                                        <property name="allowExport">true</property>
                                    </structure>
                                </list-property>
                                <method name="onPrepare"><![CDATA[vars["endDate"] = Formatter.format(params["pDate"],"dd.MM.yyyy");
vars["startDate"] = Formatter.format(BirtDateTime.addMonth( params["pDate"], -1 ),"dd.MM.yyyy");
]]></method>
                                <property name="resultSetColumn">pDate</property>
                            </data>
                        </cell>
                    </row>
                    <row id="241">
                        <property name="textAlign">center</property>
                        <property name="height">0.2916666666666667in</property>
                        <cell id="242">
                            <property name="textAlign">left</property>
                            <data id="271">
                                <property name="fontWeight">bold</property>
                                <property name="textAlign">center</property>
                                <property name="dataSet">SubRepDataSet</property>
                                <list-property name="boundDataColumns">
                                    <structure>
                                        <property name="name">PST_ADR</property>
                                        <text-property name="displayName">PST_ADR</text-property>
                                        <expression name="expression" type="javascript">"������������ ��������� ����������� " + dataSetRow["BR_RAS_NM"]</expression>
                                        <property name="dataType">string</property>
                                        <property name="allowExport">true</property>
                                    </structure>
                                </list-property>
                                <property name="resultSetColumn">PST_ADR</property>
                            </data>
                        </cell>
                    </row>
                </grid>
            </page-header>
            <page-footer>
                <grid id="254">
                    <property name="textAlign">left</property>
                    <property name="width">1.4166666666666667in</property>
                    <column id="267">
                        <property name="width">0.7083333333333334in</property>
                    </column>
                    <column id="255">
                        <property name="width">0.15625in</property>
                    </column>
                    <column id="256">
                        <property name="width">0.19791666666666666in</property>
                    </column>
                    <column id="257">
                        <property name="width">0.3541666666666667in</property>
                    </column>
                    <row id="258">
                        <cell id="266">
                            <property name="textAlign">justify</property>
                            <label id="268">
                                <property name="textAlign">left</property>
                                <text-property name="text">��������</text-property>
                            </label>
                        </cell>
                        <cell id="259">
                            <property name="textAlign">justify</property>
                            <auto-text id="260">
                                <property name="textAlign">left</property>
                                <property name="type">page-number</property>
                            </auto-text>
                        </cell>
                        <cell id="261">
                            <property name="textAlign">justify</property>
                            <text id="262">
                                <property name="textAlign">left</property>
                                <property name="contentType">plain</property>
                                <text-property name="content"><![CDATA[��]]></text-property>
                            </text>
                        </cell>
                        <cell id="263">
                            <property name="textAlign">justify</property>
                            <auto-text id="264">
                                <property name="textAlign">left</property>
                                <property name="type">total-page</property>
                            </auto-text>
                        </cell>
                    </row>
                </grid>
            </page-footer>
        </simple-master-page>
    </page-setup>
    <body>
        <table id="183">
            <property name="width">7.739583333333333in</property>
            <property name="dataSet">MainDataSet</property>
            <list-property name="boundDataColumns">
                <structure>
                    <property name="name">TODAT</property>
                    <text-property name="displayName">TODAT</text-property>
                    <expression name="expression" type="javascript">dataSetRow["TODAT"]</expression>
                    <property name="dataType">date</property>
                    <property name="allowExport">true</property>
                </structure>
                <structure>
                    <property name="name">TYPE</property>
                    <text-property name="displayName">����� - ������</text-property>
                    <expression name="expression" type="javascript">"����� - ������ " + dataSetRow["TYPE"]</expression>
                    <property name="dataType">string</property>
                    <property name="allowExport">true</property>
                </structure>
                <structure>
                    <property name="name">CBA</property>
                    <text-property name="displayName">CBA</text-property>
                    <expression name="expression" type="javascript">dataSetRow["CBA"]</expression>
                    <property name="dataType">decimal</property>
                </structure>
                <structure>
                    <property name="name">CBP</property>
                    <text-property name="displayName">CBP</text-property>
                    <expression name="expression" type="javascript">dataSetRow["CBP"]</expression>
                    <property name="dataType">decimal</property>
                </structure>
                <structure>
                    <property name="name">CBP_Head</property>
                    <text-property name="displayName">������ - ������</text-property>
                    <expression name="expression" type="javascript">"������ - ������ " + dataSetRow["TYPE"]</expression>
                    <property name="dataType">string</property>
                    <property name="allowExport">true</property>
                </structure>
                <structure>
                    <property name="name">DIFF</property>
                    <text-property name="displayName">CBP</text-property>
                    <expression name="expression" type="javascript">dataSetRow["CBA"] + dataSetRow["CBP"]</expression>
                    <property name="dataType">decimal</property>
                    <property name="allowExport">true</property>
                </structure>
            </list-property>
            <column id="207">
                <property name="width">1.0208333333333333in</property>
            </column>
            <column id="209">
                <property name="width">1.9895833333333333in</property>
            </column>
            <column id="233">
                <property name="width">1.9895833333333333in</property>
            </column>
            <column id="210">
                <property name="width">2.7395833333333335in</property>
            </column>
            <header>
                <row id="184">
                    <cell id="185"/>
                    <cell id="189"/>
                    <cell id="228"/>
                    <cell id="191"/>
                </row>
            </header>
            <group id="212">
                <property name="groupName">TypeGroup1</property>
                <expression name="keyExpr" type="javascript">row["TYPE"]</expression>
                <structure name="toc">
                    <expression name="expressionValue" type="javascript">row["TYPE"]</expression>
                </structure>
                <property name="hideDetail">false</property>
                <header>
                    <row id="213">
                        <property name="borderBottomStyle">solid</property>
                        <property name="borderBottomWidth">medium</property>
                        <property name="borderLeftStyle">solid</property>
                        <property name="borderLeftWidth">medium</property>
                        <property name="borderRightStyle">solid</property>
                        <property name="borderRightWidth">medium</property>
                        <property name="borderTopStyle">solid</property>
                        <property name="borderTopWidth">medium</property>
                        <cell id="214">
                            <property name="borderBottomStyle">solid</property>
                            <property name="borderBottomWidth">medium</property>
                            <property name="borderLeftStyle">solid</property>
                            <property name="borderLeftWidth">medium</property>
                            <property name="borderRightStyle">solid</property>
                            <property name="borderRightWidth">medium</property>
                            <property name="borderTopStyle">solid</property>
                            <property name="borderTopWidth">medium</property>
                            <label id="226">
                                <property name="backgroundAttachment">scroll</property>
                                <property name="backgroundPositionX">0%</property>
                                <property name="backgroundPositionY">0%</property>
                                <property name="backgroundRepeat">repeat</property>
                                <property name="fontFamily">sans-serif</property>
                                <property name="fontSize">10pt</property>
                                <property name="fontWeight">bold</property>
                                <property name="fontStyle">normal</property>
                                <property name="fontVariant">normal</property>
                                <property name="color">black</property>
                                <property name="textLineThrough">none</property>
                                <property name="textOverline">none</property>
                                <property name="textUnderline">none</property>
                                <property name="borderBottomStyle">none</property>
                                <property name="borderLeftStyle">none</property>
                                <property name="borderRightStyle">none</property>
                                <property name="borderTopStyle">none</property>
                                <property name="marginTop">0pt</property>
                                <property name="marginLeft">0pt</property>
                                <property name="marginBottom">0pt</property>
                                <property name="marginRight">0pt</property>
                                <property name="paddingTop">1pt</property>
                                <property name="paddingLeft">1pt</property>
                                <property name="paddingBottom">1pt</property>
                                <property name="paddingRight">1pt</property>
                                <property name="textAlign">center</property>
                                <property name="letterSpacing">normal</property>
                                <property name="lineHeight">normal</property>
                                <property name="orphans">2</property>
                                <property name="textTransform">none</property>
                                <property name="whiteSpace">normal</property>
                                <property name="widows">2</property>
                                <property name="wordSpacing">normal</property>
                                <property name="display">block</property>
                                <property name="pageBreakAfter">auto</property>
                                <property name="pageBreakBefore">auto</property>
                                <property name="pageBreakInside">auto</property>
                                <property name="showIfBlank">false</property>
                                <property name="canShrink">false</property>
                                <property name="overflow">hidden</property>
                                <text-property name="text">�� ����</text-property>
                            </label>
                        </cell>
                        <cell id="216">
                            <property name="borderBottomStyle">solid</property>
                            <property name="borderBottomWidth">medium</property>
                            <property name="borderLeftStyle">solid</property>
                            <property name="borderLeftWidth">medium</property>
                            <property name="borderRightStyle">solid</property>
                            <property name="borderRightWidth">medium</property>
                            <property name="borderTopStyle">solid</property>
                            <property name="borderTopWidth">medium</property>
                            <data name="CBA_Head" id="223">
                                <property name="backgroundAttachment">scroll</property>
                                <property name="backgroundPositionX">0%</property>
                                <property name="backgroundPositionY">0%</property>
                                <property name="backgroundRepeat">repeat</property>
                                <property name="fontFamily">sans-serif</property>
                                <property name="fontSize">10pt</property>
                                <property name="fontWeight">bold</property>
                                <property name="fontStyle">normal</property>
                                <property name="fontVariant">normal</property>
                                <property name="color">black</property>
                                <property name="textLineThrough">none</property>
                                <property name="textOverline">none</property>
                                <property name="textUnderline">none</property>
                                <property name="borderBottomStyle">none</property>
                                <property name="borderLeftStyle">none</property>
                                <property name="borderRightStyle">none</property>
                                <property name="borderTopStyle">none</property>
                                <property name="marginTop">0pt</property>
                                <property name="marginLeft">0pt</property>
                                <property name="marginBottom">0pt</property>
                                <property name="marginRight">0pt</property>
                                <property name="paddingTop">1pt</property>
                                <property name="paddingLeft">1pt</property>
                                <property name="paddingBottom">1pt</property>
                                <property name="paddingRight">1pt</property>
                                <property name="textAlign">center</property>
                                <property name="letterSpacing">normal</property>
                                <property name="lineHeight">normal</property>
                                <property name="orphans">2</property>
                                <property name="textTransform">none</property>
                                <property name="whiteSpace">normal</property>
                                <property name="widows">2</property>
                                <property name="wordSpacing">normal</property>
                                <property name="display">block</property>
                                <property name="pageBreakAfter">auto</property>
                                <property name="pageBreakBefore">auto</property>
                                <property name="pageBreakInside">auto</property>
                                <property name="showIfBlank">false</property>
                                <property name="canShrink">false</property>
                                <property name="overflow">hidden</property>
                                <property name="resultSetColumn">TYPE</property>
                            </data>
                        </cell>
                        <cell id="229">
                            <property name="borderBottomStyle">solid</property>
                            <property name="borderBottomWidth">medium</property>
                            <property name="borderLeftStyle">solid</property>
                            <property name="borderLeftWidth">medium</property>
                            <property name="borderRightStyle">solid</property>
                            <property name="borderRightWidth">medium</property>
                            <property name="borderTopStyle">solid</property>
                            <property name="borderTopWidth">medium</property>
                            <data id="236">
                                <property name="backgroundAttachment">scroll</property>
                                <property name="backgroundPositionX">0%</property>
                                <property name="backgroundPositionY">0%</property>
                                <property name="backgroundRepeat">repeat</property>
                                <property name="fontFamily">sans-serif</property>
                                <property name="fontSize">10pt</property>
                                <property name="fontWeight">bold</property>
                                <property name="fontStyle">normal</property>
                                <property name="fontVariant">normal</property>
                                <property name="color">black</property>
                                <property name="textLineThrough">none</property>
                                <property name="textOverline">none</property>
                                <property name="textUnderline">none</property>
                                <property name="borderBottomStyle">none</property>
                                <property name="borderLeftStyle">none</property>
                                <property name="borderRightStyle">none</property>
                                <property name="borderTopStyle">none</property>
                                <property name="marginTop">0pt</property>
                                <property name="marginLeft">0pt</property>
                                <property name="marginBottom">0pt</property>
                                <property name="marginRight">0pt</property>
                                <property name="paddingTop">1pt</property>
                                <property name="paddingLeft">1pt</property>
                                <property name="paddingBottom">1pt</property>
                                <property name="paddingRight">1pt</property>
                                <property name="textAlign">center</property>
                                <property name="letterSpacing">normal</property>
                                <property name="lineHeight">normal</property>
                                <property name="orphans">2</property>
                                <property name="textTransform">none</property>
                                <property name="whiteSpace">normal</property>
                                <property name="widows">2</property>
                                <property name="wordSpacing">normal</property>
                                <property name="display">block</property>
                                <property name="pageBreakAfter">auto</property>
                                <property name="pageBreakBefore">auto</property>
                                <property name="pageBreakInside">auto</property>
                                <property name="showIfBlank">false</property>
                                <property name="canShrink">false</property>
                                <property name="overflow">hidden</property>
                                <property name="resultSetColumn">CBP_Head</property>
                            </data>
                        </cell>
                        <cell id="217">
                            <property name="borderBottomStyle">solid</property>
                            <property name="borderBottomWidth">medium</property>
                            <property name="borderLeftStyle">solid</property>
                            <property name="borderLeftWidth">medium</property>
                            <property name="borderRightStyle">solid</property>
                            <property name="borderRightWidth">medium</property>
                            <property name="borderTopStyle">solid</property>
                            <property name="borderTopWidth">medium</property>
                            <text id="225">
                                <property name="backgroundAttachment">scroll</property>
                                <property name="backgroundPositionX">0%</property>
                                <property name="backgroundPositionY">0%</property>
                                <property name="backgroundRepeat">repeat</property>
                                <property name="fontFamily">sans-serif</property>
                                <property name="fontSize">10pt</property>
                                <property name="fontWeight">bold</property>
                                <property name="fontStyle">normal</property>
                                <property name="fontVariant">normal</property>
                                <property name="color">black</property>
                                <property name="textLineThrough">none</property>
                                <property name="textOverline">none</property>
                                <property name="textUnderline">none</property>
                                <property name="borderBottomStyle">none</property>
                                <property name="borderLeftStyle">none</property>
                                <property name="borderRightStyle">none</property>
                                <property name="borderTopStyle">none</property>
                                <property name="marginTop">0pt</property>
                                <property name="marginLeft">0pt</property>
                                <property name="marginBottom">0pt</property>
                                <property name="marginRight">0pt</property>
                                <property name="paddingTop">1pt</property>
                                <property name="paddingLeft">1pt</property>
                                <property name="paddingBottom">1pt</property>
                                <property name="paddingRight">1pt</property>
                                <property name="textAlign">center</property>
                                <property name="letterSpacing">normal</property>
                                <property name="lineHeight">normal</property>
                                <property name="orphans">2</property>
                                <property name="textTransform">none</property>
                                <property name="whiteSpace">normal</property>
                                <property name="widows">2</property>
                                <property name="wordSpacing">normal</property>
                                <property name="display">block</property>
                                <property name="pageBreakAfter">auto</property>
                                <property name="pageBreakBefore">auto</property>
                                <property name="pageBreakInside">auto</property>
                                <property name="showIfBlank">false</property>
                                <property name="canShrink">false</property>
                                <property name="overflow">hidden</property>
                                <property name="contentType">auto</property>
                                <text-property name="content"><![CDATA[����������� (�-�)]]></text-property>
                            </text>
                        </cell>
                    </row>
                </header>
                <footer>
                    <row id="218">
                        <cell id="219"/>
                        <cell id="221"/>
                        <cell id="231"/>
                        <cell id="222"/>
                    </row>
                </footer>
            </group>
            <detail>
                <row id="193">
                    <cell id="194">
                        <data id="195">
                            <structure name="dateTimeFormat">
                                <property name="category">Custom</property>
                                <property name="pattern">dd.MM.yyyy</property>
                                <property name="locale">ru</property>
                            </structure>
                            <property name="resultSetColumn">TODAT</property>
                        </data>
                    </cell>
                    <cell id="198">
                        <data id="199">
                            <property name="backgroundAttachment">scroll</property>
                            <property name="backgroundPositionX">0%</property>
                            <property name="backgroundPositionY">0%</property>
                            <property name="backgroundRepeat">repeat</property>
                            <property name="fontFamily">serif</property>
                            <property name="fontSize">10pt</property>
                            <property name="fontWeight">normal</property>
                            <property name="fontStyle">normal</property>
                            <property name="fontVariant">normal</property>
                            <property name="color">black</property>
                            <property name="textLineThrough">none</property>
                            <property name="textOverline">none</property>
                            <property name="textUnderline">none</property>
                            <property name="borderBottomColor">black</property>
                            <property name="borderBottomStyle">none</property>
                            <property name="borderBottomWidth">medium</property>
                            <property name="borderLeftColor">black</property>
                            <property name="borderLeftStyle">none</property>
                            <property name="borderLeftWidth">medium</property>
                            <property name="borderRightColor">black</property>
                            <property name="borderRightStyle">none</property>
                            <property name="borderRightWidth">medium</property>
                            <property name="borderTopColor">black</property>
                            <property name="borderTopStyle">none</property>
                            <property name="borderTopWidth">medium</property>
                            <property name="marginTop">0pt</property>
                            <property name="marginLeft">0pt</property>
                            <property name="marginBottom">0pt</property>
                            <property name="marginRight">0pt</property>
                            <property name="paddingTop">1pt</property>
                            <property name="paddingLeft">1pt</property>
                            <property name="paddingBottom">1pt</property>
                            <property name="paddingRight">1pt</property>
                            <structure name="numberFormat">
                                <property name="category">Currency</property>
                                <property name="pattern">#,##0.00{RoundingMode=HALF_UP}</property>
                                <property name="locale">ru_RU</property>
                            </structure>
                            <property name="textAlign">right</property>
                            <property name="letterSpacing">normal</property>
                            <property name="lineHeight">normal</property>
                            <property name="orphans">2</property>
                            <property name="textTransform">none</property>
                            <property name="whiteSpace">normal</property>
                            <property name="widows">2</property>
                            <property name="wordSpacing">normal</property>
                            <property name="display">block</property>
                            <property name="pageBreakAfter">auto</property>
                            <property name="pageBreakBefore">auto</property>
                            <property name="pageBreakInside">auto</property>
                            <property name="showIfBlank">false</property>
                            <property name="canShrink">false</property>
                            <property name="overflow">hidden</property>
                            <property name="resultSetColumn">CBA</property>
                        </data>
                    </cell>
                    <cell id="230">
                        <data id="235">
                            <property name="backgroundAttachment">scroll</property>
                            <property name="backgroundPositionX">0%</property>
                            <property name="backgroundPositionY">0%</property>
                            <property name="backgroundRepeat">repeat</property>
                            <property name="fontFamily">serif</property>
                            <property name="fontSize">10pt</property>
                            <property name="fontWeight">normal</property>
                            <property name="fontStyle">normal</property>
                            <property name="fontVariant">normal</property>
                            <property name="color">black</property>
                            <property name="textLineThrough">none</property>
                            <property name="textOverline">none</property>
                            <property name="textUnderline">none</property>
                            <property name="borderBottomColor">black</property>
                            <property name="borderBottomStyle">none</property>
                            <property name="borderBottomWidth">medium</property>
                            <property name="borderLeftColor">black</property>
                            <property name="borderLeftStyle">none</property>
                            <property name="borderLeftWidth">medium</property>
                            <property name="borderRightColor">black</property>
                            <property name="borderRightStyle">none</property>
                            <property name="borderRightWidth">medium</property>
                            <property name="borderTopColor">black</property>
                            <property name="borderTopStyle">none</property>
                            <property name="borderTopWidth">medium</property>
                            <property name="marginTop">0pt</property>
                            <property name="marginLeft">0pt</property>
                            <property name="marginBottom">0pt</property>
                            <property name="marginRight">0pt</property>
                            <property name="paddingTop">1pt</property>
                            <property name="paddingLeft">1pt</property>
                            <property name="paddingBottom">1pt</property>
                            <property name="paddingRight">1pt</property>
                            <structure name="numberFormat">
                                <property name="category">Currency</property>
                                <property name="pattern">#,##0.00{RoundingMode=HALF_UP}</property>
                                <property name="locale">ru_RU</property>
                            </structure>
                            <property name="textAlign">right</property>
                            <property name="letterSpacing">normal</property>
                            <property name="lineHeight">normal</property>
                            <property name="orphans">2</property>
                            <property name="textTransform">none</property>
                            <property name="whiteSpace">normal</property>
                            <property name="widows">2</property>
                            <property name="wordSpacing">normal</property>
                            <property name="display">block</property>
                            <property name="pageBreakAfter">auto</property>
                            <property name="pageBreakBefore">auto</property>
                            <property name="pageBreakInside">auto</property>
                            <property name="showIfBlank">false</property>
                            <property name="canShrink">false</property>
                            <property name="overflow">hidden</property>
                            <property name="resultSetColumn">CBP</property>
                        </data>
                    </cell>
                    <cell id="200">
                        <data id="201">
                            <structure name="numberFormat">
                                <property name="category">Currency</property>
                                <property name="pattern">#,##0.00{RoundingMode=HALF_UP}</property>
                                <property name="locale">ru_RU</property>
                            </structure>
                            <property name="textAlign">right</property>
                            <property name="resultSetColumn">DIFF</property>
                        </data>
                    </cell>
                </row>
            </detail>
            <footer>
                <row id="202">
                    <cell id="203"/>
                    <cell id="205"/>
                    <cell id="232"/>
                    <cell id="206"/>
                </row>
            </footer>
        </table>
    </body>
    <property name="pageVariables">
        <variable-element name="startDate">
            <property name="type">report</property>
        </variable-element>
        <variable-element name="endDate">
            <property name="type">report</property>
        </variable-element>
    </property>
</report>
', '', '2016-03-28 16:35:29.494495', 'IMBUSER', null);


insert into
DWH.RP_SQLS ( 
	RPTEMPLATS_ID, 
	PARENT_ID, 
	ORDER_NUM, 
	SQL_TEXT
    )
    VALUES
    (
	25, 
	null, 
	1, 
	'call DWH.DWHBALCHK(?,?)'
    );

insert into
DWH.RP_SQLS ( 
	RPTEMPLATS_ID, 
	PARENT_ID, 
	ORDER_NUM, 
	SQL_TEXT
    )
    VALUES
    (
	25, 
	null, 
	2, 
	'call DWH.DWH_BRDATA(?,'''')'
    );

insert into
DWH.RP_PARAMS ( 
	RP_SQLS_ID, 
    CODE,
    NAME,
    DATA_TYPE,
    DATA_DIM,
    VALUE,
    REQUIRE_SIGN,
    SAVE_SIGN,
    HIDDEN_SIGN,
    SHOW_ORDER,
    PARAMS
)
VALUES
(
    1, 
    'pDate',
    '���� ������',
    3,
    0,
    '2016-03-01',
    1,
    1,
    0,
    1,
    null
);    

insert into
DWH.RP_PARAMS ( 
	RP_SQLS_ID, 
    CODE,
    NAME,
    DATA_TYPE,
    DATA_DIM,
    VALUE,
    REQUIRE_SIGN,
    SAVE_SIGN,
    HIDDEN_SIGN,
    SHOW_ORDER,
    PARAMS
)
VALUES
(
    1, 
    'pBranch',
    '������',
    0,
    0,
    '0000',
    1,
    1,
    0,
    2,
    null
);    