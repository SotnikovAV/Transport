Changes:

perspective\DevprogPerspective - added dfc view
dfc\*


ideas: create a method for pulling in DFC scripts from the web directly into repoint
you could share dfc calls, make it really impressive by creating reports on users and
groups that could be saved immediately online

pie graph for number of users in groups

cvs file of cleaned up query not available through dql

