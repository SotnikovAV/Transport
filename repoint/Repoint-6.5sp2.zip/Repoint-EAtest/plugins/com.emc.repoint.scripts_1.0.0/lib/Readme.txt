
Place the Beanshell jar in this folder. Rename it to 'bsh.jar'.

Download the Beanshell JAR from this location - 
http://www.beanshell.org/download.html

Download the first JAR that includes everything (~280KB).



